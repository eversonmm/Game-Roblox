
# Meu Jogo PGZero

## Estrutura
- `game.py`: código principal do jogo.
- `images/`: sprites do herói e inimigos.
- `sounds/`: efeitos de som (jump, hit).
- `music/`: música de fundo.

## Instalação
```bash
pip install -r requirements.txt
pgzrun game.py
```
