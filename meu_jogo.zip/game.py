import pgzrun
from random import randint

WIDTH, HEIGHT = 640, 480

class SpriteAnim:
    def __init__(self, images, speed):
        self.frames = [Actor(img) for img in images]
        self.index, self.speed, self.timer = 0, speed, 0

    def draw(self, pos):
        self.frames[self.index].pos = pos
        self.frames[self.index].draw()

    def update(self):
        self.timer += 1
        if self.timer >= self.speed:
            self.index = (self.index + 1) % len(self.frames)
            self.timer = 0

class Hero:
    def __init__(self):
        self.pos = [100, HEIGHT - 50]
        self.vy = 0
        self.on_ground = True
        self.idle = SpriteAnim(["hero_idle1", "hero_idle2"], 20)
        self.run = SpriteAnim(["hero_run1", "hero_run2"], 10)
        self.current = self.idle

    def draw(self): self.current.draw(self.pos)
    def update(self):
        self.current.update()
        self.pos[1] += self.vy
        if self.pos[1] < HEIGHT - 50:
            self.vy += 1
        else:
            self.pos[1], self.vy, self.on_ground = HEIGHT - 50, 0, True

    def jump(self):
        if self.on_ground:
            sounds.jump.play()
            self.vy, self.on_ground = -15, False

class Enemy:
    def __init__(self):
        self.pos = [randint(200, WIDTH-50), HEIGHT - 50]
        self.walk = SpriteAnim(["enemy_walk1", "enemy_walk2"], 15)

    def draw(self): self.walk.draw(self.pos)
    def update(self): self.walk.update()

hero, enemies = Hero(), [Enemy() for _ in range(3)]
game_state = "menu"

def draw():
    screen.clear()
    if game_state == "menu":
        screen.draw.text("MENU PRINCIPAL", center=(WIDTH/2, 100), fontsize=40)
        screen.draw.text("Pressione ESPACO para Jogar", center=(WIDTH/2, 200), fontsize=30)
    else:
        hero.draw()
        for e in enemies: e.draw()

def update():
    if game_state == "game":
        hero.update()
        for e in enemies: e.update()

def on_key_down(key):
    global game_state
    if game_state == "menu" and key == keys.SPACE:
        music.play("bg_music")
        game_state = "game"
    elif game_state == "game" and key == keys.UP:
        hero.jump()

pgzrun.go()
